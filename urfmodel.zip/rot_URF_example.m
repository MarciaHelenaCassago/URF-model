%Universidade Federal do Esp�rito Santo
%Chemistry Post-Graduate Program
%PhD Student: Marcia Helena Cassago
%Coordinators:
%Doctor Paulo Roberto Filgueiras
%Doctor Wanderson Rom�o

%Script for example of the Unsupervised Random Forest (URF)

%Loading dataset example
load nirEVOO

%Samples name vector
nsamples=1:size(X,1); nsamples=nsamples';
nSamples=cell(size(nsamples,1),1);
for ki=1:size(nsamples,1)
    a=nsamples(ki,1);
    b=num2str(a);
    nSamples{ki,1}=b;
end
clear a b ki

%% Set options of running URF
options.Xpretreat   = {'none'};                   % preprocessing during RF growth trees.
options.leafs       = 50;                         % max number leaves during otimization of CV.
options.cv          = 10;                         % kfold
options.cort        = 0.7;                        % Exact cut valeu to accepctance of the model
options.nrep        = 1;                          % Indication of there are replicas Default: 1 (not have replicas)
options.partes      = ceil(sqrt(size(X,2)));      % mtry 
options.SplitCri    = 'gdi';                      % Split Criterion : 'gdi' or 'deviance'.
options.PruneCrit   = 'impurity';                 %Prune Criterion : 'impurity' or 'error'.
%options.n_var      = ceil(3);                    %  number of variable per tree.
%options.n_var      = ceil(sqrt(size(Xtrain,2))); %  number of variable per tree.
options.trees       = 500;                       % Ntree - number of trees in the model.
options.permutation = 0;                          % permutation to variable selection, [1: yes]; [0: no]
options.graficos    = 0;
options.graficoRF   = 1;                          % graph of the most important variables in RF
options.outlier     = 1;                          % Outlier generation option: 
                                                    %1: artificial outlier generation/ 2: permutation variables
options.past2       = 'C:\Users\Marcia Cassago\OneDrive\URF_github';
        

ModelURF_PCoA = urfmodel(X,[],nSamples,nsamples,5,11,classX,options);

cd(options.past2)
save modelo_URF.mat
clear
clc

