function [model2,model,m] = rf_class5(Xcal,ycal,Xtest,ytest,options)
% rfmodel = rf_class3(X,y,options)
% Random Forest Model for classification
% input : 
%  Xcal : train dataset of independents variable; (nxm)  
%  ycal : class of the each sample in Xtrain; (nx1)
%  Xtest : test dataset of independents variable; (nxm)  
%  ytest : class of the each sample in Xtest; (nx1)
% + options : set for optimize the random forest;
%   + Xpretreat   : preprocessing X data.
%   + leafs       : optimization of the number of leafs in the cross validation;
%   + cv          : k of k-fold; 
%   + SplitCri    : Split Criterion: 'deviance'; 'gdi';   default('gdi')
%   +PruneCrit    : Prune Criterion : 'impurity' or 'error'; default('impuruty')
%   + n_var       : number of variable per tree (default sqrt(m));
%   + trees       : number of tree in randon forest. 
%   + permutation : permutation to variable selection, [1: yes]; [0: no]  default (0)
%   + graph    :  output graph; 0 No (default 0);
%   + graphRF   : variable plot RF (default 1);
%
% output :
% - model : random forest model 
% - model2 : random forest performance metrics 
%    yp : Matrix with 3 columns.
%          1  : class precited.
%          2  : Mode for class predicted.
%          3  : probability of the sample belonging to that class.
%    YtestPred : All predictions for test samples.
%    AccPred   : All accuracies calculated for test samples.
%    RandPred  : delta(Acc) = Acc(real) - Acc(random).
%                The greater the sum of the RandPred columns, the more important will be the variable. 
%                sum(rfmodel.RandPred)
%   classPedit : Class predicte to test samples.
%   diagnostic  : Performance testing results for model.
%
%   
%
% Paulo Roberto Filgueiras  -  22/05/2018
%



if nargin==2
options.Xpretreat   = {'none'}; 
options.nrep        = 1; 
options.leafs       = 20;       
options.partes      = 50;       
options.cv          = 10;        
options.SplitCri    = 'gdi';      
options.PruneCrit   = 'impurity'; 
options.n_var       = ceil(sqrt(size(X,2)));  
options.trees       = 500;     
options.permutation = 0;      
options.graph    = 0;
options.graphRF   = 1;      
end

partes = round((options.partes/100)*size(Xcal,2));

model2.acc=[]; model2.acctest=[]; 
model2.var=[];
model2.predp=zeros(length(ycal),options.trees);
model2.predtest=zeros(length(ytest),options.trees);
model=cell(options.trees,10);

for ki=1:options.trees
    var_sel=randperm(size(Xcal,2)); 
    var_sel=var_sel(1:partes); 
    if options.nrep>1
        samprep=1:options.nrep:size(ycal,1); samprep=samprep';
        out=bootrsp(1:length(samprep),1);
        out2=out*options.nrep;
        out1=[];
        for ki=1:size(out2,2)
            a=out2(1,ki);
            b=a-(options.nrep-1);
            out1=[out1,b,a];
        end
        
        sample_in=unique(out1);
    else
        out=bootrsp(1:length(ycal),1); 
        sample_in=unique(out); 
    end
    
test=setxor(1:length(ycal),sample_in); 
saida = arvore_class(Xcal(out,var_sel),ycal(out),options);  
modelo = arvore_test(saida,Xcal(test,var_sel),ycal(test));  
modelo2 = arvore_test(saida,Xcal(sample_in,var_sel),ycal(sample_in)); 
    if ~isempty(Xtest)
        modelo3 = arvore_test(saida,Xtest(:,var_sel),ytest);
        model{ki,1}=saida;%Tree model
        model{ki,2}=modelo2; %Model InBag
        model{ki,3}=modelo; %Model Out-of-Bag
        model{ki,4}=out; %permuted lines
        model{ki,5}=sample_in; %In-Bag
        model{ki,6}=test; %OOB
        model{ki,7}=var_sel; %variables randomized selected
        model{ki,8}=modelo3; % External test model
        model{ki,9}=Xtest(:,var_sel); %External test dataset
        model{ki,10}=ytest; %External test actual class
        model2.acc=[model2.acc; modelo.accuracy]; %OOB Accuracy
        model2.var=[model2.var;var_sel]; %Variables
        model2.predp(test,ki)=modelo.classPrevista(:,end); %class predicted for the test sample ...
        %in the trees that it participated as a test. If it did not participate, it is left
        %with zero
        model2.predtest(:,ki)=modelo3.classPrevista(:,end); 
        model2.acctest=[model2.acctest; modelo3.accuracy];
       
              
        
    elseif isempty(Xtest)
        model{ki,1}=saida;
        model{ki,2}=modelo2;
        model{ki,3}=modelo;
        model{ki,4}=out;
        model{ki,5}=sample_in;
        model{ki,6}=test;
        model{ki,7}=var_sel;
        model2.acc=[model2.acc; modelo.accuracy];
        model2.var=[model2.var; var_sel];
        model2.predp(test,ki)=modelo.classPrevista(:,end); 
        % predcted class for the test sample
        
       
    end
    m{ki,1}=model{ki,1}.tree.CutPredictor; %Predictor variables
    
end
             
    if isempty(Xtest)
       [model2.acc,ord]=sort(model2.acc,'descend');
        model2.var=model2.var(ord,:);
        model2.predp=model2.predp(:,ord);
       
        % Accuracy OOB
        model2.class=unique(ycal);
        model2.ypred=zeros(size(ycal,1),size(model2.class,1)*2);
        
        for ki=1:length(ycal)
            xp=[];
            for kj=1:length(model2.class)
                x1=length(find(model2.predp(ki,:)==model2.class(kj)));
                x1=100*x1/size(model2.predp,2);
                xp=[xp,x1];%column numbers = class numbers
            end
            x1=find(xp==max(xp));%most appeared class
            x1a=model2.class(x1,1);
            model2.ypred(ki,1)=ycal(ki,1);
            model2.ypred(ki,2)=x1a(1,1);
            model2.ypred(ki,3:3+size(xp,2)-1)=xp(1,1:end);
        end
        [~,model2.diagnostic]=class_matriz(model2.ypred(:,1),model2.ypred(:,2));
        model2.class_param = calc_class_param(model2.ypred(:,1),model2.ypred(:,2));
        clear ki kj x1 x1a xp

    
        
                
    elseif ~isempty(Xtest)
        [model2.acc,ord]=sort(model2.acc,'descend');
        [model2.acctest,ord2]=sort(model2.acctest,'descend'); 
        model2.var=model2.var(ord,:);
        model2.predp=model2.predp(:,ord);
        model2.predtest=model2.predtest(:,ord2);
        
        % Accuracy OOB
        model2.class=unique(ycal);
        model2.ypred=zeros(size(ycal,1),size(model2.class,1)*2);
        
        for ki=1:length(ycal)
            xp=[];
            for kj=1:length(model2.class)
                x1=length(find(model2.predp(ki,:)==model2.class(kj)));
                x1=100*x1/size(model2.predp,2);
                xp=[xp,x1];%column numbers = class numbers
            end
            x1=find(xp==max(xp));%most appeared class
            x1a=model2.class(x1,1);
            model2.ypred(ki,1)=ycal(ki,1);
            model2.ypred(ki,2)=x1a(1,1);
            model2.ypred(ki,3:3+size(xp,2)-1)=xp(1,1:end);
        end
        [~,model2.diagnostic]=class_matriz(model2.ypred(:,1),model2.ypred(:,2));
        model2.class_param = calc_class_param(model2.ypred(:,1),model2.ypred(:,2));
        clear ki kj x1 x1a xp
        
        % Accuracy test
        model2.classtest=unique(ytest);
        model2.ypredtest=zeros(size(ytest,1),size(model2.classtest,1)*2);
        for ki=1:length(ytest)
            xp=[];
            for kj=1:length(model2.classtest)
                x1=length(find(model2.predtest(ki,:)==model2.classtest(kj)));
                x1=100*x1/size(model2.predtest,2);
                xp=[xp,x1];
            end
            x1=find(xp==max(xp));
            x1a=model2.classtest(x1,1);
            model2.ypredtest(ki,1)=ytest(ki,1);
            model2.ypredtest(ki,1)=ytest(ki,1);
            model2.ypredtest(ki,2)=x1a(1,1);
            model2.ypredtest(ki,3:3+size(xp,2)-1)=xp(1,1:end);
        end
        [~,model2.diagnosticteste]=class_matriz(model2.ypredtest(:,1),model2.ypredtest(:,2));
        model2.class_param = calc_class_param(model2.ypredtest(:,1),model2.ypredtest(:,2));
                
    end
    

