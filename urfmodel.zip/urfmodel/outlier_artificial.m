function out = outlier_artificial(X,Msamples,npc,sd)
% out = outlier_artificial(X,Msamples,npc,sd)
% Function to generate random outliers 
%
% X : Input X datase (m lines and n column);
% Msamples : (scalar) Number of generated artificial outliers;
% npc : (scalar <= n) Number o principal component used to determine the random
% outliers;
% sd : (scalar) standard deviation (default = 3);
% 
% Exemple: out = outlier_artificial(X,200,2,3);
% 
% Prof. Paulo R. Filgueiras  - 20/04/2020
%


if nargin ==3; sd=3; end
%+++++ 1st Step: change of vector base
% Data centered at zero
Xmean = mean(X);
X = X-ones(size(X,1),1)*mean(X);
[T,P,varexp] = pca(X,npc);

%+++++ 2st Step: Generation of artificial outliers in the new base 
V=cov(T);
[~,autovalor]=eig(V);
val = flip(diag(autovalor));
semieixo = (sd*sqrt(val))'; % length of each semi-axis of the ellipse

Tm = mean(T); % Mean of T
Ts = std(T);  % Standard deviation of T

elipse = []; % Points inside and outside the ellipse
outlier = []; % Outliers samples
ki=0;
while ki<Msamples
    elipse_rand = (randn(1,size(T,2)).*Ts) + Tm;
    elipse1 = (elipse_rand.^2)./(semieixo.^2);    
    if sum(elipse1)>1
        outlier = [outlier ; elipse_rand];
        ki=ki+1;
    end
    % elipse = [elipse; sum(elipse1)];
    elipse = [elipse; sum(elipse1)];
end

   
%+++++ 3rd Step: Return the artificial outliers to the source base 
outlier = outlier*P';
outlier2 = outlier + ones(size(outlier,1),1)*Xmean;
%+++++ Output
out.outlier = outlier2;
out.P = P;
out.varexp = varexp;


%===== Subfunction
function [T,P,varexp] = pca(X,npc)
%  Principal Componentes Analysis by SVD
[n,m] = size(X);
if m < n
  cov = (X'*X);
  [u,s,v] = svd(cov);
  PCnumber = (1:m)';
else
  cov = (X*X');
  [u,s,v] = svd(cov);
  v = X'*v;
  for i = 1:n
    v(:,i) = v(:,i)/norm(v(:,i));
  end
  PCnumber = (1:n)';
end
individualExpVar = diag(s)*100/(sum(diag(s)));
varexp  = [PCnumber individualExpVar cumsum(individualExpVar)];
P  = v(:,1:npc);
T = X*P;

