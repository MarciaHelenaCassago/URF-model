function [classPrevist,diagnostic]=class_matriz(Yref,Yprevisto)
% Routine to calculate the diagnostic parameters in problems of
% classification 
%
% input:
%      Yref : Y reference values.
%      Yprevisto : Y predicted values.
% 
% output:
% classPrevist : predicted class for each sample. The predicted class takes 
%                 into account the column of each Yref class.
%                 Matrix with two columns:
%                 classPrevist(:,1) = Reference Y values.
%                 classPrevist(:,2) = Predicted Y values.
% 
%  diagnostic : diagnostics set for qualitative problems
%                 using method 1 against all. 
%                 Diagnostics will have a structure for each Yref class.
%  ++ confMatrix ++ TP     : total of true positive.
%                ++ TN     : total of true negative.
%                ++ FP     : total of false positive.
%                ++ FN     : total of false negative.
%
%  ++ Sensitivity : model sensitivity.
%  ++ Specificity : model specificity.
%  ++         VPP : positive value prevalence.
%  ++         VPN : negative value prevalence.
%  ++    accuracy : model accuracy.
%  ++         TFP : false positive rate
%  ++         TFP : false negative rate
%  ++         TCF : reliability rate
%
% Example:
% [classPrevist,diagnostic]=class_matriz(Yref,Yprevisto);
%
% ++   Paulo R. Filgueiras  - 19/08/2014
%

if ~isvector(Yref)
    [Yref2,a1,classes] = vet_matrix(Yref); % Yref as a vector
else
    Yref2=Yref;
end

if ~isvector(Yref)
    class_prev=[];
    for ki=1:size(Yprevisto,1)
        [a1,a2]=max(Yprevisto(ki,:));
        class_prev=[class_prev;a2];
    end
else
    class_prev=round(Yprevisto);
end

classPrevist=[Yref2,class_prev]; % Vector with the actual class and predicted class

Matriz_contin=confusionmat(classPrevist(:,1),classPrevist(:,2));

diagnostic.confMatrix{1,1}='Diagnostic';
diagnostic.confMatrix{1,2}='TP';
diagnostic.confMatrix{1,3}='TN';
diagnostic.confMatrix{1,4}='FP';
diagnostic.confMatrix{1,5}='FN';
for ki=1:length(Matriz_contin)
    diagnostic.confMatrix{ki+1,1}=strcat('Class_',num2str(ki));
    TP=Matriz_contin(ki,ki);
    TN=sum(sum(Matriz_contin))+TP-sum(Matriz_contin(:,ki))-sum(Matriz_contin(ki,:));
    FP=sum(Matriz_contin(:,ki))-TP;
    FN=sum(Matriz_contin(ki,:))-TP;
    diagnostic.confMatrix{ki+1,2}=TP;
    diagnostic.confMatrix{ki+1,3}=TN;
    diagnostic.confMatrix{ki+1,4}=FP;
    diagnostic.confMatrix{ki+1,5}=FN;
end

diagnostic.Sensitivity=[];
diagnostic.Specificity=[];
diagnostic.VPP=[];
diagnostic.VPN=[];
diagnostic.Accuracy=[];
diagnostic.TFP=[]; % false positive rate
diagnostic.TFN=[]; % false negative rate
diagnostic.TCF=[]; % reliability rate  
for ki=1:length(Matriz_contin)
    Sensitivity=diagnostic.confMatrix{ki+1,2}/(diagnostic.confMatrix{ki+1,2}+diagnostic.confMatrix{ki+1,5});
    Specificity=diagnostic.confMatrix{ki+1,3}/(diagnostic.confMatrix{ki+1,3}+diagnostic.confMatrix{ki+1,4});
    VPP=diagnostic.confMatrix{ki+1,2}/(diagnostic.confMatrix{ki+1,2}+diagnostic.confMatrix{ki+1,4});
    VPN=diagnostic.confMatrix{ki+1,3}/(diagnostic.confMatrix{ki+1,3}+diagnostic.confMatrix{ki+1,5});
    accuracy=(diagnostic.confMatrix{ki+1,2}+diagnostic.confMatrix{ki+1,3})/...
        (diagnostic.confMatrix{ki+1,2}+diagnostic.confMatrix{ki+1,3}+ ...
        diagnostic.confMatrix{ki+1,4}+diagnostic.confMatrix{ki+1,5});
    TFP=diagnostic.confMatrix{ki+1,4}/(diagnostic.confMatrix{ki+1,4}+diagnostic.confMatrix{ki+1,3});
    TFN=diagnostic.confMatrix{ki+1,5}/(diagnostic.confMatrix{ki+1,5}+diagnostic.confMatrix{ki+1,2});
    TCF=1-TFP-TFN;
    diagnostic.Sensitivity=[diagnostic.Sensitivity,Sensitivity];
    diagnostic.Specificity=[diagnostic.Specificity,Specificity];
    diagnostic.VPP=[diagnostic.VPP,VPP];
    diagnostic.VPN=[diagnostic.VPN,VPN];
    diagnostic.Accuracy=[diagnostic.Accuracy,accuracy];
    diagnostic.TFP=[diagnostic.TFP,TFP];
    diagnostic.TFN=[diagnostic.TFN,TFN];
    diagnostic.TCF=[diagnostic.TCF,TCF];
end

diagnostic.exat=sum(diag(Matriz_contin))/sum(sum(Matriz_contin));
