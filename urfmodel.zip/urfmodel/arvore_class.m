function model = arvore_class(Xtrain,ytrain,options)
% model = arvore_class(Xtrain,ytrain,options)
% decision tree for classification
% 
% options
% options.Xpretreat : Preprocessing methods. default {'center'};
% options.leafs : Number of leafs testing in the crosso validations
% options.partes : k of k-fold; standard 10.  
% options.SplitCri  = 'gdi'; % 'gdi' or 'deviance' . Split Criterion
% options.PruneCrit='impurity'; %'impurity' or 'error'
% options.n_graf : 1 output graph; 0 No
% example: saida = arvore_class(Xtrain,ytrain,options)
%
% Paulo Roberto Filgueiras : 15/09/2014
%
if nargin==2
    options.Xpretreat = {'center'}; 
    options.leafs     = 50;
    options.partes    = 10;
    options.cv        = 10;
    options.SplitCri  = 'gdi'; % 'gdi' or 'deviance'
    options.PruneCrit = 'impurity'; %'impurity' or 'error'
    options.graficos  = 0;
end

model.data.date=date;
model.modelo='classification_tree';
model.options=options;
model.data.Xtrain=Xtrain;
model.data.ytrain=ytrain;

Xtrain=pretrat(Xtrain,[],options.Xpretreat);
leafs = linspace(1,size(Xtrain,1)/2,options.leafs); %leafs [10,100] 
N = numel(leafs); 
model.err = zeros(N,1);
for n=1:N
    t = ClassificationTree.fit(Xtrain,ytrain,'kfold',options.cv,'minleaf',leafs(n),...
        'PruneCriterion',options.PruneCrit,'SplitCriterion',options.SplitCri);
    model.err(n) = kfoldLoss(t);
end
[a1 a2]=min(model.err);a2=a2(1);model.leafs=round(leafs(a2));

model.tree = ClassificationTree.fit(Xtrain,ytrain,'minleaf',model.leafs,...
    'PruneCriterion',options.PruneCrit,'SplitCriterion',options.SplitCri);

model.yc=predict(model.tree,Xtrain);
[model.classPrevista,model.diagnosticos]=class_matriz(ytrain,model.yc);


%% Graph
if options.graficos==1
    figure(1)
    plot(leafs,model.err);hold on ,plot(leafs,model.err,'ro') 
    xlabel('Min Leaf Size');
    ylabel('cross-validated error');
    view(model.tree,'mode','graph');
end



