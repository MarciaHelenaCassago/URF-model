function graph_score3_4(T,classX,varexp)

[a1,classes]=confusionmat(classX,classX);

figure(4)
if length(classes)==1
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1)); 
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    legend(d1)
elseif length(classes)==2
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1)); 
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold off
    legend(d1,d2)
elseif length(classes)==3
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold off
    legend(d1,d2,d3)
elseif length(classes)==4
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold off
    legend(d1,d2,d3,d4)
elseif length(classes)==5
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold off
    legend(d1,d2,d3,d4,d5)
elseif length(classes)==6
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold off
    legend(d1,d2,d3,d4,d5,d6)    
elseif length(classes)==7
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    c7=find(classX==classes(7));   x7=T(c7,:);   d7=sprintf('Classe %g',classes(7));    
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold on
    plot(x7(:,3),x7(:,4),'ko','LineWidth',1,'MarkerSize',8), hold off
    legend(d1,d2,d3,d4,d5,d6,d7)  
elseif length(classes)==8
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    c7=find(classX==classes(7));   x7=T(c7,:);   d7=sprintf('Classe %g',classes(7));    
    c8=find(classX==classes(8));   x8=T(c8,:);   d8=sprintf('Classe %g',classes(8));  
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold on
    plot(x7(:,3),x7(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.5,.5,.5]), hold on
    plot(x8(:,3),x8(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.64,.08,.18]), hold off
    legend(d1,d2,d3,d4,d5,d6,d7,d8)            
elseif length(classes)==9
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    c7=find(classX==classes(7));   x7=T(c7,:);   d7=sprintf('Classe %g',classes(7));    
    c8=find(classX==classes(8));   x8=T(c8,:);   d8=sprintf('Classe %g',classes(8));  
    c9=find(classX==classes(9));   x9=T(c9,:);   d9=sprintf('Classe %g',classes(9)); 
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold on
    plot(x7(:,3),x7(:,4),'ko','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.5,.5,.5]), hold on
    plot(x8(:,3),x8(:,4),'ro','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.64,.08,.18]), hold on
    plot(x9(:,3),x9(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[0,204/255,204/255]), hold off
    legend(d1,d2,d3,d4,d5,d6,d7,d8,d9)                
elseif length(classes)==10
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    c7=find(classX==classes(7));   x7=T(c7,:);   d7=sprintf('Classe %g',classes(7));    
    c8=find(classX==classes(8));   x8=T(c8,:);   d8=sprintf('Classe %g',classes(8));  
    c9=find(classX==classes(9));   x9=T(c9,:);   d9=sprintf('Classe %g',classes(9)); 
    c10=find(classX==classes(10)); x10=T(c10,:); d10=sprintf('Classe %g',classes(10)); 
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold on
    plot(x7(:,3),x7(:,4),'ko','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.5,.5,.5]), hold on
    plot(x8(:,3),x8(:,4),'ro','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.64,.08,.18]), hold on
    plot(x9(:,3),x9(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[0,204/255,204/255]), hold on
    plot(x10(:,3),x10(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[204/255,204/255,1]), hold off
    legend(d1,d2,d3,d4,d5,d6,d7,d8,d9,d10)     
elseif length(classes)==11
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    c7=find(classX==classes(7));   x7=T(c7,:);   d7=sprintf('Classe %g',classes(7));    
    c8=find(classX==classes(8));   x8=T(c8,:);   d8=sprintf('Classe %g',classes(8));  
    c9=find(classX==classes(9));   x9=T(c9,:);   d9=sprintf('Classe %g',classes(9)); 
    c10=find(classX==classes(10)); x10=T(c10,:); d10=sprintf('Classe %g',classes(10)); 
    c11=find(classX==classes(11)); x11=T(c11,:); d11=sprintf('Classe %g',classes(11)); 
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold on
   plot(x7(:,3),x7(:,4),'ko','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.5,.5,.5]), hold on
    plot(x8(:,3),x8(:,4),'ro','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.64,.08,.18]), hold on
    plot(x9(:,3),x9(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[0,204/255,204/255]), hold on
    plot(x10(:,3),x10(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[204/255,204/255,1]), hold on
    plot(x11(:,3),x11(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[204/255,204/255,1]), hold off
    legend(d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11)     
elseif length(classes)==12
    c1=find(classX==classes(1));   x1=T(c1,:);   d1=sprintf('Classe %g',classes(1));
    c2=find(classX==classes(2));   x2=T(c2,:);   d2=sprintf('Classe %g',classes(2));
    c3=find(classX==classes(3));   x3=T(c3,:);   d3=sprintf('Classe %g',classes(3));
    c4=find(classX==classes(4));   x4=T(c4,:);   d4=sprintf('Classe %g',classes(4));
    c5=find(classX==classes(5));   x5=T(c5,:);   d5=sprintf('Classe %g',classes(5));
    c6=find(classX==classes(6));   x6=T(c6,:);   d6=sprintf('Classe %g',classes(6));    
    c7=find(classX==classes(7));   x7=T(c7,:);   d7=sprintf('Classe %g',classes(7));    
    c8=find(classX==classes(8));   x8=T(c8,:);   d8=sprintf('Classe %g',classes(8));  
    c9=find(classX==classes(9));   x9=T(c9,:);   d9=sprintf('Classe %g',classes(9)); 
    c10=find(classX==classes(10)); x10=T(c10,:); d10=sprintf('Classe %g',classes(10)); 
    c11=find(classX==classes(11)); x11=T(c11,:); d11=sprintf('Classe %g',classes(11)); 
    c12=find(classX==classes(12)); x12=T(c12,:); d12=sprintf('Classe %g',classes(12)); 
    plot(x1(:,3),x1(:,4),'ko','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.8,.8,.8]), hold on
    plot(x2(:,3),x2(:,4),'ro','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,153/255]), hold on
    plot(x3(:,3),x3(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,153/255,1]), hold on
    plot(x4(:,3),x4(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[.47,.67,.19]), hold on
    plot(x5(:,3),x5(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[1,153/255,1]), hold on
    plot(x6(:,3),x6(:,4),'co','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[153/255,1,1]), hold on
    plot(x7(:,3),x7(:,4),'ko','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.5,.5,.5]), hold on
    plot(x8(:,3),x8(:,4),'ro','LineWidth',1,'MarkerSize',10, 'MarkerFaceColor',[.64,.08,.18]), hold on
    plot(x9(:,3),x9(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[0,204/255,204/255]), hold on
    plot(x10(:,3),x10(:,4),'mo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[198/255,198/255,1]), hold on
    plot(x11(:,3),x11(:,4),'bo','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[200/255,200/255,1]), hold on
    plot(x12(:,3),x12(:,4),'go','LineWidth',1,'MarkerSize',10,'MarkerFaceColor',[204/255,204/255,1]), hold off
    legend(d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12)     
end

hline(0,'k:'),vline(0,'k:');
t1=sprintf('Scores PC 3 (%0.2f)',varexp(3,2));  xlabel(t1,'FontSize',14)
t2=sprintf('Scores PC 4 (%0.2f)',varexp(4,2));  ylabel(t2,'FontSize',14)


function h = hline(y,lc)
[m,n] = size(y);
v = axis;
if ishold
  for ii=1:m
    h(ii) = plot(v(1:2),[1 1]*y(ii,1),lc);
  end
else
  hold on
  for ii=1:m
    h(ii) = plot(v(1:2),[1 1]*y(ii,1),lc);
  end
  hold off
end

if nargout == 0;
  clear h
end

function h = vline(x,lc)
[m,n] = size(x);
if m>1&n>1
  error('Error - input must be a scaler or vector')
elseif n>1
  x   = x';
  m   = n;
end

v     = axis;
if ishold
  for ii=1:m
    h(ii) = plot([1 1]*x(ii,1),v(3:4),lc);
  end
else
  hold on
  for ii=1:m
    h(ii) = plot([1 1]*x(ii,1),v(3:4),lc);
  end
  hold off
end

if nargout == 0;
  clear h
end
