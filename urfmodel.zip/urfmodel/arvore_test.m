function modelo = arvore_test(model,Xtest,ytest)
% decision tree for classification and regression
% leafs - optimization of leaf number in the cross-validation
% exemplo: modelo = arvore_test(saida,Xtest,ytest)

switch lower(model.modelo)
  case 'classification_tree'
   if nargin==3
     [~,Xtest]=pretrat(model.data.Xtrain,Xtest,model.options.Xpretreat);
    [modelo.pred,modelo.score,modelo.node,modelo.cnum]=predict(model.tree,Xtest);
    modelo.cm=confusionmat(ytest,modelo.pred);
    modelo.accuracy=sum(diag(modelo.cm))/(sum(sum(modelo.cm)));
    [modelo.classPrevista,modelo.diagnosticos]=class_matriz(ytest,modelo.pred);
   else
   [modelo.pred,modelo.score,modelo.node,modelo.cnum]=predict(model.tree,Xtest);
   end
   
  case 'regression_tree'
   if nargin==3
    modelo.pred=predict(model.tree,Xtest);
    modelo.RMSEP = sqrt(sum((modelo.pred-ytest).^2)/length(ytest));
    modelo.R2p=corrcoef(modelo.pred,ytest);modelo.R2p=modelo.R2p(1,2)^2;
    if model.options.n_graf==1
    plot(model.dados.ycal,model.cv,'ko');hold on
    plot(ytest,modelo.pred,'k+'); lsline
    legend('Cross Validation','Prediction')
    xlabel('Measured');
    ylabel('Predicted');
    end
   else
   modelo.pred=predict(model.tree,Xtest);
   end
end
