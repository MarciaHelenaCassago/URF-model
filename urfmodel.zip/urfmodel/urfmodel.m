function ModelURF_PCoA = urfmodel(Xtrain,Xtest,nsamples,samples,method,windderiv,classX,options)
%Unsupervised Random Forest (URF) model
%Input:
    %Xtrain = training spectral data 
    %Xtest = test spectral data
    %nsamples = a string vector  with sample names
    %samples = a numeric vector with samples code 
    %method = pre-processing method cod
        %1 = Center;
        %2 = MSC
        %3 = SNV
        %4 = first derivative, polynomial degree 2 - need add window number - standard 7
        %5 = second derivative, polynomial degree 2 - need add window number - standard 7
        %6 = Normalization by the norm
        %7 = autosclaling
        %8 = none
    %classX = column vector with sample's class
    %windderiv - for derivative pre-processing method  if is not : []
    %options: 
        %options.outlier = outlier generation method: 
            %1: artificial outliers
            %2: permutation variables
        %options.nrep = indica��o se h� r�plicatas
            %1 = Standard - no replicate - mean of spectrum replicate
            %This script is not adapted for analysis with replicas
        %options.past2= a string vector where models and figures will be saved
            %Standard = {'Current folder'}

 
if nargin ==8
    
    %options
    if ~isstruct(options)
        options.Xpretreat   = {'none'};     % pre-processing X data.
        options.leafs       = 50;           % maximal number of leafs.
        options.cv          = 10;           % k-fold number
        options.nrep        = 1;            % there isn't replicate
        options.partes      = 10;           % Percentage of variables used in the tree 
        options.SplitCri    = 'gdi';        % Split Criterion : 'gdi' or 'deviance'.
        options.PruneCrit   = 'impurity';   % Prune Criterion : 'impurity' or 'error'.
        %options.n_var      = ceil(3);      % number of variable per tree.
        %options.n_var      = ceil(sqrt(size(Xtrain,2)));  %  number of variable per tree
        options.trees       = 1000;         % number of trees in the forest number.
        options.permutation = 0;            % permutation to variable selection, [1: yes]; [0: no]
        options.graphs    = 0;
        options.graphRF   = 1;            % relevant variable graphic (it is disabled)
        options.outlier     = 1;            % Outlier generation method: 1: artificial outlier/ 2: permutation variables
        options.past2       =cd();          % current folder
    end
    
    %classX
    if isempty(classX)
        classX=ones(size(Xtrain,1),1);
    end
    
    %windderiv method
    if ~isempty(windderiv)
        if fix(windderiv)-windderiv ~=0 || mod(windderiv,2)==0
        %Error message
        error('The entered in winderiv must be an einteger and odd numbers')
        end
    end
            
    %method
    
    if method(1,1)>8 || method(1,1)<0 || fix(method)-method ~=0
        error('method must be an integer from 1 to 8, see processing options with "help urfmodel" command')
    end
    
    %samples
    if ~isempty(samples)
        if ~isnumeric(samples) || size(samples,2)>1
            error('samples must be a vector with sample number or code')
        end
    end
                
    %nsamples
    if isempty(nsamples) || isnumeric(nsamples)
        nsamples=cell(size(samples,1),1);
        for i=1:size(samples,1)
            a=samples(i,1);
            b=num2str(a);
            nsamples{i,1}=b;
        end
    end
            
    %Xtest    
    %if ~isempty(Xtest)
        %Xtest=Xtest;
    %end
    
    %Xtrain
       %Xtrain=Xtrain;
             
elseif nargin ==7
    %options
    options.Xpretreat   = {'none'}; 
    options.leafs       = 50;       
    options.cv          = 10;         
    options.nrep        = 1; 
    options.partes      = 5;        
    options.SplitCri    = 'gdi';      
    options.PruneCrit   = 'impurity'; 
    %options.n_var      = ceil(3); 
    %options.n_var      = ceil(sqrt(size(Xtrain,2))); 
    options.trees       = 1000;     
    options.permutation = 0;      
    options.graphs    = 0;
    options.graphRF   = 1;      
    options.outlier     = 1;    
    options.past2       =cd(); 
    
    
    %classX
    if isempty(classX)
        classX=ones(size(Xtrain,1),1);
    end
        
    %windderiv method
    if ~isempty(windderiv)
        if fix(windderiv)-windderiv ~=0 || mod(windderiv,2)==0
            %Mensagem de erro
            error('The entered in winderiv must be an einteger and odd numbers')
        end
    end
        
    %method
   if method(1,1)>8 || method(1,1)<0 || fix(method)-method ~=0
        error('method must be an integer from 1 to 8, see processing options with "help urfmodel" command')
    end
    
    %samples
    if ~isempty(samples)
        if ~isnumeric(samples) || size(samples,2)>1
            error('samples must be a vector with sample number or code')
        end
    end
    
    %nsamples
    if isempty(nsamples) || isnumeric(nsamples)
       nsamples=cell(size(samples,1),1);
        for i=1:size(samples,1)
            a=samples(i,1);
            b=num2str(a);
            nsamples{i,1}=b;
        end
    end
            
    %Xtest    
    %if ~isempty(Xtest)
        %Xtest=Xtest;
    %end
    
    %Xtrain
    %Xtrain=Xtrain;
    
elseif nargin==6
    
    %options
    options.Xpretreat   = {'none'}; 
    options.leafs       = 50;       
    options.cv          = 10;         
    options.nrep        = 1; 
    options.partes      = 5;       
    options.SplitCri    = 'gdi';     
    options.PruneCrit   = 'impurity'; 
    %options.n_var      = ceil(3);  
    %options.n_var      = ceil(sqrt(size(Xtrain,2)));  
    options.trees       = 1000;    
    options.permutation = 0;      
    options.graphs    = 0;
    options.graphRF   = 1;      
    options.outlier     = 1;    
    options.past2       =cd();
        
    %classX
    classX=ones(size(Xtrain,1),1);
        
    %windderiv method
    if ~isempty(windderiv)
        if fix(windderiv)-windderiv ~=0 || mod(windderiv,2)==0
            %Mensagem de erro
            error('The entered in winderiv must be an einteger and odd numbers')
        end
    end
    
    %method
    %method=method;
    if method(1,1)>8 || method(1,1)<0 || fix(method)-method ~=0
        error('method must be an integer from 1 to 8, see processing options with "help urfmodel" command')
    end
    
    %samples
    if ~isempty(samples)
        %samples=samples;
        if ~isnumeric(samples) || size(samples,2)>1
            error('samples must be a vector with sample number or code')
        end
    end
    
    %nsamples
    if isempty(nsamples) || isnumeric(nsamples)
       nsamples=cel(size(samples,1),1);
        for i=1:size(samples,1)
            a=samples(i,1);
            b=num2str(a);
            nsamples{i,1}=b;
        end
    end
            
    %Xtest    
    %if ~isempty(Xtest)
        %Xtest=Xtest;
    %end
    
    %Xtrain
    %Xtrain=Xtrain;
    
elseif nargin==5
    
    %options
    options.Xpretreat   = {'none'}; 
    options.leafs       = 50;       
    options.cv          = 10;         
    options.nrep        = 1; 
    options.partes      = 5;       
    options.SplitCri    = 'gdi';      
    options.PruneCrit   = 'impurity'; 
    %options.n_var      = ceil(3);  
    %options.n_var      = ceil(sqrt(size(Xtrain,2)));  
    options.trees       = 1000;    
    options.permutation = 0;      
    options.graphs    = 0;
    options.graphRF   = 1;      
    options.outlier     = 1;    
    options.past2       =cd(); 
    
    %classX
    classX=ones(size(Xtrain,1),1);
        
    %windderiv method
    windderiv=7;
    
    %method
    %method=method;
    if method(1,1)>8 || method(1,1)<0 || fix(method)-method ~=0
        error('method must be an integer from 1 to 8, see processing options with "help urfmodel" command')
    end
    
    %samples
    if ~isempty(samples)
        if ~isnumeric(samples) || size(samples,2)>1
            error('samples must be a vector with sample number or code')
        end
    end
    
    %nsamples
    if isempty(nsamples) || isnumeric(nsamples)
        nsamples=cell(size(samples,1),1);
        for i=1:size(samples,1)
            a=samples(i,1);
            b=num2str(a);
            nsamples{i,1}=b;
        end
    end
            
    %Xtest    
    %if ~isempty(Xtest)
        %Xtest=Xtest;
    %end
    
    %Xtrain
       %Xtrain=Xtrain;
       
elseif nargin==4
    
    %options
    options.Xpretreat   = {'none'}; 
    options.leafs       = 50;       
    options.cv          = 10;         
    options.cort        = 0.7;      % Cutoff for RF model to arrive the dissimilarity matriz and PCoA analysis  
    options.nrep        = 1; 
    options.partes      = 5;      
    options.SplitCri    = 'gdi';      
    options.PruneCrit   = 'impurity'; 
    %options.n_var      = ceil(3);  
    %options.n_var      = ceil(sqrt(size(Xtrain,2)));  
    options.trees       = 1000;     
    options.permutation = 0;      
    options.graphs    = 0;
    options.graphRF   = 1;      
    options.outlier     = 1;    
    options.past2       =cd(); 
    
    %classX
    classX=ones(size(Xtrain,1),1);
    
    %windderiv method
    windderiv=7;
    
    %method
    method=6;
    
    %samples
    if ~isempty(samples)
        if ~isnumeric(samples) || size(samples,2)>1
            error('samples must be a vector with sample number or code')
        end
    end
    
    %nsamples
    if isempty(nsamples) || isnumeric(nsamples)
        nsamples=cell(size(samples,1),1);
        for i=1:size(samples,1)
            a=samples(i,1);
            b=num2str(a);
            nsamples{i,1}=b;
        end
    end
            
    %Xtest    
    %if ~isempty(Xtest)
        %Xtest=Xtest;
    %end
    
    %Xtrain
       %Xtrain=Xtrain;
       
elseif nargin<4
    %mensagem de erro entrada
    error('Input must have at least 4 inputs: Xtrain, Xtest, nsamples, samples')
end
    
  %Pre-processing methods
  methods{1,1}={'center'}; methods{2,1}={'msc'}; methods{3,1}={'snv'};
  methods{4,1}={'deriv',[7,2,1]}; methods{5,1}={'deriv',[7,2,2]};
  methods{6,1}={'norm'};methods{7,1}={'auto'}; methods{8,1}={'none'};
  
  if method==1
      method=methods{1,1};
      disp('Pre-processing: center')
      elseif method==2
           method=methods{2,1};
           disp('Pre-processing: msc')
           elseif method==3
               method=methods{3,1};
               disp('Pre-processing: snv')
               elseif method==4
                   methods{4, 1}{1,2}=[windderiv(1,1) 2 1];
                   method=methods{4,1};
                   disp('Pre-processing: 1� derivada')
                   disp(methods{4, 1}{1,2})
                   elseif method==5
                       methods{5, 1}{1,2}=[windderiv(1,1) 2 2];
                       method=methods{5,1};
                       disp('Pre-processing: 2� derivada')
                       disp(methods{5, 1}{1,2})
                       elseif method==6
                           method=methods{6,1};
                           disp('Pre-processing: norm')
                           elseif method==7
                               method=methods{7,1};
                               disp('Pre-processing: autoescalamento')
                               elseif method==8
                                   method=methods{8,1};
                                   disp('Pre-processing: none')
  end



%% Outliers generation
tstart=tic;

if options.outlier==1
    %Artificial outliers
    %Data matrix of original Xtrain plus Xtest data matrix
    if ~isempty(Xtest)
        Xtrain=[Xtrain;Xtest];
        classX2=ones(size(Xtest,1),1)*max(classX)+1;
        class=unique(classX);
        classes=cell(size(class,1),1);
        for km=1:size(class,1)
            a=class(km,1);
            b=num2str(a);
            classes{km,1}=b;
        end
        classX=[classX;classX2];
        class2={'Test'};
        classes{end+1,1}=class2;
        else
        %Xtrain=Xtrain;
        %classX=classX;
        class=unique(classX);
        classes=cell(size(class,1),1);
        for km=1:size(class,1)
            a=class(km,1);
            b=num2str(a);
            classes{km,1}=b;
        end
    end
    
     [n,~]=size(Xtrain);
     % routine "outlier_artificial"
     artif = outlier_artificial(Xtrain,n*3,3,3);
     Xrn=artif.outlier;
     
     %Concatenate matrices
     Xnew=[Xtrain;Xrn];
     
     %To create the classes column vector
     %Original x Synthetics
     [n1,~]=size(Xtrain);
     [n,~]=size(Xnew);
     
     y=[];
     y(1:n1,1)=1; %Original data;
     y(n1+1:n,1)=2; %Synthetic data;
     
elseif options.outlier==2
    %Outliers generation by permutation of variables by samples
        %Deconstructs the relationship between samples and variables
    
    if ~isempty(Xtest)
        Xtrain=[Xtrain;Xtest];
        classX2=ones(size(Xtest,1),1)*max(classX)+1;
        class=unique(classX);
        classes=cell(size(class,1),1);
        for km=1:size(class,1)
            a=class(km,1);
            b=num2str(a);
            classes{km,1}=b;
        end
        classX=[classX;classX2];
        classes{end+1,1}={'Teste'};
    else
        %Xtrain=Xtrain;
        %classX=classX;
        class=unique(classX);
        classes=cell(size(class,1),1);
        for km=1:size(class,1)
            a=class(km,1);
            b=num2str(a);
            classes{km,1}=b;
        end
    end
       
    %Randomization of variables
    
    [n,~]=size(Xtrain);
    n=n*3;
    n_out=bootrsp(1:size(Xtrain,1),2); 
    D=size(n_out,1)*size(n_out,2);
    n_out=reshape(n_out,D,1);
    n_dif=(n-size(Xtrain,1));
    Xtrain2=[Xtrain;Xtrain(n_out(1:n_dif),:)];
    
    Xrn=ones(size(Xtrain2));
    for ki=1:size(Xtrain2,2)
        var_out=randperm(size(Xtrain2,1));
        Xrn(:,ki)=Xtrain2(var_out,ki);
    end
    
    %Concatenate matrices
    Xnew=[Xtrain;Xrn];
    
    %Same n-outliers of Xtrain (no repetition)   
    %Xrn=ones(size(Xtrain));
    %for ki=1:size(Xtrain,2)
        %var_sel=randperm(size(Xtrain,1));
        %Xrn(:,ki)=Xtrain(var_sel,ki);
    %end
    
    %To create the class column vector
    %Original x Synthetics
    [n1,~]=size(Xtrain);
    [n,~]=size(Xnew);
    
    y(1:n1,1)=1; %Original data;
    y(n1+1:n,1)=2; %Synthetic data;
end
    
    %% RF Model
    
    %pr�-processamento dos dados
     Xd=pretrat(Xnew,[],method);
    
    % Model
    fprintf('Random forest in progress...\n')
    [model2,model,~] = rf_class5(Xd,y,[],[],options);
    fprintf('Random forest completed.\n')
    
    %To identify frequency of selected predictor variables in the model
        %c=model2.var;
        %Data = [];
        %for ki=1:numel(m)
            %p1 = m{ki,1};
            %a1 = ~cellfun(@isempty,p1);
            %a2 = find(a1);
            %subdata=[];
                %for kj=1:length(a2)
                    %b1 = a2(kj);
                    %b2 = p1(b1);
                    % b3 = str2num(b2{1}(2));
                    %b4 = c(ki,b3);
                    %subdata = [subdata;b4];
                %end
            %Data = [Data;subdata];
        %end
        %c3=1:numel(m);
        %vs=zeros(1,size(Xd,2));
        %for ki=1:size(Xd,2)
            %k3=sum(Data==ki);
        %end
        %bar(1:size(Xd,2),vs)
        %ylabel('Frequency','FontSize',14)
        %xlabel('Variable','FontSize',14)
        %cd(options.past2)
        %savefig ('Variables')
        %close 1
         %clear ki m kj k3 c a1 a2 b1 b2 b3 b4 p1 n2

 
 ModelURF_PCoA.model2=model2;
 ModelURF_PCoA.model=model;
 %cd(options.past2)
 %save modelo_URF.mat
 cort=options.cort;  
%%
if model2.diagnosticos.exat>=cort
    % Proximity matrix
    %nodes Leafs in Tree
    modelo=cell(size(model,1),5);
    for ki=1:size(model,1)
    [Leafs,~]=find(model{ki,1}.tree.Children==0);
    Leafs2=unique(Leafs);
    modelo{ki,1}=ki; %tree number
    modelo{ki,2}=model{ki, 1}.tree.NumNodes; %number of nodes
    modelo{ki,3}=Leafs2; %tree leaf node    
    end
    clear ki Leafs Leafs2
    
    %OOB sample nodes
    [m,~]=size(Xd);
    Samples_URF=zeros(m);
    
    for k=1:size(modelo,1)
        Leaf=modelo{k,3};
        NODES=cell(size(Leaf,1),2);
        for kj=1:size(Leaf,1)
            [A,~]=find(model{k,2}.node==Leaf(kj,1));
            B=model{k,5}(1,A);%Samples In Bag 
            NODES{kj,1}=Leaf(kj,1);
            NODES{kj,2}=B; 
            for i=1:size(B,2)
                if i< size(B,2)
                    for j=i+1:size(B,2)
                        Samples_URF(B(i),B(j))=Samples_URF(B(i),B(j))+1;
                        Samples_URF(B(j),B(i))=Samples_URF(B(j),B(i))+1;
                    end
                end
            end
            modelo{k,4}=size(Leaf,1);
        end
        modelo{k,5}=NODES; %sample In-Bag nodes
        clear NODES
    end
    
    clear m n i j k kj Leaf
    
    %Out-of-Bag samples
    
    for k=1:size(modelo,1)
    Leaf=modelo{k,3};
    for kj=1:size(Leaf,1)
        [A,~]=find(model{k,3}.node==Leaf(kj,1));
        B=model{k,6}(1,A);%Samples Out-of-Bag 
        NODES{kj,1}=Leaf(kj,1);
        NODES{kj,2}=B; 
        for i=1:size(B,2)
            if i< size(B,2)
                for j=i+1:size(B,2)
                    Samples_URF(B(i),B(j))=Samples_URF(B(i),B(j))+1;
                    Samples_URF(B(j),B(i))=Samples_URF(B(j),B(i))+1;
                end
            end
        end
        %modelo{k,4}=size(Leaf,1);%number of nodes
    end
    modelo{k,6}=NODES;%Out-of-Bag sample nodes
    clear NODES
    end

    clear m n i j k kj Leaf
    
    %Normalization byu the number of trees
    A=size(model,1);
    Matriz_Proximity=Samples_URF./A;
    Matriz_proximity_Real=Matriz_Proximity(1:n1,1:n1);
    Matriz_Dissimilarity=1-Matriz_proximity_Real;
    
    %Dissimilarity matrix fugure
    %nsamples=1:size(Xnew,1);
    %nsamples=nsamples';
    
    %samples={};
    %for ki=1:n1
    %a=nsamples(ki,1);
    %b=num2str(a);
    %samples=[samples,b];
    %end

    %samples=samples';
    
    %figure(2)  
    %label=nsamples;
    %cd(caminhos{2,1});
    %matrixblobs(Matriz_Dissimilarity,label,[1 1 0]);
    %cd(options.past2)
    %savefig (2,'Matriz_Dissimilarity_URF')
    %close 2
    
    imagesc(Matriz_proximity_Real)
    cd(options.past2)
    savefig ('Graf_Matriz_Proximity_URF')
    close all
    
    %Double mean-centered
    Dissim=Matriz_Dissimilarity;
    for k=1:size(Matriz_Dissimilarity,1)
    for j=1:size(Matriz_Dissimilarity,2)
        a=Dissim(k,j)-mean(Dissim(k,:))-mean(Dissim(:,j));
        b=mean(Dissim); c=mean(b);
        d=a+c;
        Dissim(k,j)=d;        
    end
    end

    clear a b c d B A j k ki label subdata
           
    %% PCoA model
       
    dis=f_dis(Dissim);
    diag=0; scale=1; neg=0;
    result = f_pcoa_2(dis,diag,scale,neg);
    
    samples1=cell(size(samples,1),1);
    for i=1:size(samples,1)
        a=samples(i,1);
        b=num2str(a);
        samples1{i,1}=b;
    end
    [hdl,~] = f_pcoaPlot(result,samples1);
    cd(options.past2)
    savefig('model_PCoA_2D')
    close 1
    
    ModelURF_PCoA.PCoA.result=result;
        
    %cd(options.past2)
    %save model_URF_PCoA.mat
    
    %Gr�fico 3D
    
    T=result.scores; n1=1; n2=2; n3=3; varexp=result.expl;
    graph3d_score(T,n1,n2,n3,classX,varexp)
    legend(classes)
    cd(options.past2)
    savefig('modelo_PCoA_3D')
    
    %Sample names in the graph
    for ki=1:size(T,1)
    text(T(ki,n1),T(ki,n2),T(ki,n3),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_3Dsamples')
    close all
    
    % Other PC combinations
    
    T=result.scores; n1=1; n2=2; n3=3; n4=4; n5=5; varexp=result.expl;
    graph_score1_2(T,classX,varexp)
    legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC1_2')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n1),T(ki,n2),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_PC1_2samples')
    close all
    
   
    graph_score1_3(T,classX,varexp)
    legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC1_3')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n1),T(ki,n3),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end
    
    cd(options.past2)
    savefig('model_PCoA_PC1_3samples')
    close all
    
   
    graph_score1_4(T,classX,varexp)
    %legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC1_4')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n1),T(ki,n4),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_PC1_4samples')
    close all
    
    graph_score1_5(T,classX,varexp)
    %legend(classes)
    cd(options.past2)
    savefig('modelo_PCoA_PC1_5')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n1),T(ki,n5),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_PC1_5samples')
    close all
    
   
    graph_score2_3(T,classX,varexp)
    %legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC2_3')
    
    %Sample names
    for ki=1:size(T,1)
   text(T(ki,n2),T(ki,n3),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_PC2_3samples')
    close all
    
    
    graph_score2_4(T,classX,varexp)
    %legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC2_4')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n2),T(ki,n4),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 

    end
    
    cd(options.past2)
    savefig('model_PCoA_PC2_4samples')
    close all
    
    
    graph_score2_5(T,classX,varexp)
    %legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC2_5')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n2),T(ki,n5),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_PC2_5samples')
    close all
    
    
    graph_score3_4(T,classX,varexp)
    %legend(classes)
    cd(options.past2)
    savefig('model_PCoA_PC3_4')
    
    %Sample names
    for ki=1:size(T,1)
    text(T(ki,n3),T(ki,n4),samples1(ki),'HorizontalAlignment','left',...
        'VerticalAlignment','middle','Color','k','FontSize',12); 
    end

    cd(options.past2)
    savefig('model_PCoA_PC3_4samples')
    close all
    
    %Output
    if options.outlier==1
        model2.artif=artif;
    end
    ModelURF_PCoA.model2=model2;
    ModelURF_PCoA.model=model;
    ModelURF_PCoA.modelo=modelo;
    %ModelURF_PCoA.vs=vs;
    ModelURF_PCoA.Matriz_proximity_real=Matriz_proximity_Real;
    ModelURF_PCoA.Dissim=Dissim;
    ModelURF_PCoA.Matriz_Dissimilarity=Matriz_Dissimilarity;
    ModelURF_PCoA.Samples_URF=Samples_URF;
    ModelURF_PCoA.PCoA.hdl=hdl;
    ModelURF_PCoA.PCoA.T=T;
    ModelURF_PCoA.PCoA.result=result;
    ModelURF_PCoA.PCoA.varexp=varexp;
    ModelURF_PCoA.PCoA.dis=dis;
    ModelURF_PCoA.PCoA.options.diag=diag;
    ModelURF_PCoA.PCoA.options.hdl=hdl;
    ModelURF_PCoA.PCoA.options.neg=neg;
    ModelURF_PCoA.PCoA.options.scale=scale;
    Time=toc(tstart);
    ModelURF_PCoA.Time=Time;
    %cd(options.past2)
    %save modelo_URF_PCoA.mat
    clc
else
     %Output
     if options.outlier==1
         model2.artif=artif;
     end
    ModelURF_PCoA.model2=model2;
    ModelURF_PCoA.model=model;
   % ModelURF_PCoA.modelo=modelo;
    %ModelURF_PCoA.vs=vs;
    Time=toc(tstart);
    ModelURF_PCoA.Time=Time;
    
    %cd(options.past2)
    %save modelo_URF.mat
    clc
end
end
